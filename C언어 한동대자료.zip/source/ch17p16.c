#include <stdio.h>

int main(void)
{
   double a[2], *p, *q;
   p = &a[0];		/* points at base of array */
   q = p + 1;		/* equivalent to q = &a[1]; */
 
   printf("%d\n", q - p );		
   printf("%d\n", (int) q - (int) p );
   printf("%d\n", sizeof(double));
   return 0;
}
