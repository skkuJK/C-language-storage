  
#include <stdio.h>
#include <ctype.h>

int found_next_word(void);

int main(void) {
    int word_count = 0;

	printf( "Enter several words: \n");
    while (found_next_word() == 1)
         ++word_count;
    printf( "Number of words = %d\n\n", word_count);
    return 0;
}  /* end of main */
			   
/* ( Continue��.) */

int found_next_word(void)
{
  int c;
  while ( isspace( c = getchar() ) )
	; 				/* skip white space */
    if( c != EOF )  {			/* found a word */
	 while ( ( c =getchar() ) != EOF && !isspace(c) ); 
	       /* skip all except EOF and white space */
	return 1;
   }
  return 0;
}

 

