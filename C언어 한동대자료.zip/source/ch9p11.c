#include <stdio.h>
   
int sum(int n){ 	
	int j, x=0; 	
	for(j=1; j<=n; j++) 
		x=x+j;
	return x;
}
main( ){
	int x=10, y=5;
	int total;
	sum(x); 
	total = sum(x) + sum(y); 
	printf("Sum is %d", total); 
 } 

