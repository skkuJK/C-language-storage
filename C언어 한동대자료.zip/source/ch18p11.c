#include <stdio.h>
main( )
{   
   int  a[5] = {5, 4, 3, 2, 1}, *p1 , *p2 , **p3;
   p1 = a + 1;
   p2 = p1; p3 = &p2 ;		/* �� */
   printf("%d %d %d %d\n", a[2], *p1, *p2, *p3);
   (*p2)++; p3 = &p1 ; 		/* �� */
   printf("%d %d %d %d\n", a[2], *p1, *p2, *p3); 
   *(a + 2) = *p1 + *p2 + **p3;   	/* �� */
   printf("%d %d %d %d\n", a[2], *p1, *p2, *p3);
}
