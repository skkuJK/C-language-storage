#include <stdio.h>
main( )
{   
   char *p_word = "abc";
   printf("%u\n", p_word);
   p_word="def";
   printf("%u\n", p_word);
}
