#include <stdio.h>
main() 
{ 
  int a=1;
  int b=2;
  int c=0;

  c = a++ + c;
  printf("a=%d, c=%d\n", a, c);
  c = ++b + c;
  printf("b=%d, c=%d\n", b, c);
  return 0;
}
