#include <stdio.h>
main() 
{ 
	int j,k;
	int sum;

  for ( j = 1 ; j <= 5 ; j++ ) {
	for ( k = 1, sum = 0 ; k <= 3 ; k++ )
		if ( j != k )
			sum += j + k ;
	printf ("%d\t%d\t%d\n", sum, j, k ) ;
	}
 

}
