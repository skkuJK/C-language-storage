#include <stdio.h>
   
void function(int i, int j);

int main(void) {
	int i, j;

	i = 1; j = 1;
	function(i, j);
	function(2, 8);
	function(2+3, 8*2*(2+3));
}

void function(int i, int j) {
	printf("In function, i=%d, j =%d\n", i, j);
}
