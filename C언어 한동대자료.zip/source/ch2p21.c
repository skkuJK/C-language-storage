#include <stdio.h>
main(){ 
  int n = 0;
  int sum = 0;
  int i=0;

  while ( n < 10 ) {
     scanf( "%d" , &i );
     if ( i != 0 ) {
         sum += i; 
         n++;
	 }
   }
  printf( "Sum = %d\n", sum ); 
}

